import { createFileRoute } from "@tanstack/react-router";
import banner from "@/assets/banner.png";
import {
  Rocket,
  Compass,
  ListChecks,
  Sparkles,
  Brain,
  Target,
  Zap,
  Users,
  CheckCircle2,
  ArrowRight,
  Lightbulb,
  Map as MapIcon,
  PlayCircle,
} from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "LaunchFly.io — The first step from idea to takeoff" },
      {
        name: "description",
        content:
          "LaunchFly helps you go from 'I want to start something' to knowing what to build, how to start, and what to do next. $19/month.",
      },
      { property: "og:title", content: "LaunchFly.io — The first step from idea to takeoff" },
      {
        property: "og:description",
        content: "Personalized ideas, a 30-day launch path, and daily next steps for builders.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: LandingPage,
});

function Nav() {
  return (
    <header className="absolute inset-x-0 top-0 z-30">
      <div className="glass-nav border-b border-border/40">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <a href="#top" className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-gold shadow-gold">
              <Rocket className="h-4 w-4 -rotate-45 text-gold-foreground" />
            </span>
            <span className="text-lg font-semibold tracking-tight">
              LaunchFly<span className="text-gold">.io</span>
            </span>
          </a>
          <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
            <a href="#how" className="transition hover:text-foreground">How It Works</a>
            <a href="#features" className="transition hover:text-foreground">Features</a>
            <a href="#pricing" className="transition hover:text-foreground">Pricing</a>
            <a href="#faq" className="transition hover:text-foreground">FAQ</a>
          </nav>
          <a
            href="#pricing"
            className="inline-flex items-center gap-2 rounded-full bg-gradient-gold px-4 py-2 text-sm font-medium text-gold-foreground shadow-gold transition hover:opacity-90"
          >
            Start Your Launch
            <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </div>
    </header>
  );
}

function Banner() {
  return (
    <section id="top" className="relative h-[78vh] min-h-[560px] w-full overflow-hidden">
      <img
        src={banner}
        alt="Builder coding late at night, focused on launching their idea"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-banner-overlay" />
      <div className="pointer-events-none absolute inset-0 bg-warm-glow" />

      {/* Banner overlay content */}
      <div className="absolute inset-x-0 top-20 z-10 mx-auto max-w-7xl px-6">
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
            <Sparkles className="h-3.5 w-3.5 text-gold" /> The launch OS for first-time builders
          </span>
        </div>
        <h2 className="mt-4 text-lg font-semibold leading-tight text-foreground sm:text-xl md:text-[1.55rem]">
          Where late nights turn into <span className="text-gradient-gold">real<br /></span><span style={{ color: "oklch(0.68 0.18 55)" }}>launches</span>.
        </h2>
      </div>

      <div className="absolute inset-x-0 bottom-10 z-10 mx-auto max-w-7xl px-6">
        <div className="flex items-end justify-between gap-4">
          <p className="text-[0.8rem] uppercase tracking-[0.25em] text-gold/90">
            Welcome to your launch phase,
          </p>
          <div className="flex items-center gap-2.5">
            <span className="grid h-10 w-10 place-items-center rounded-lg bg-gradient-gold shadow-gold">
              <Rocket className="h-5 w-5 -rotate-45 text-gold-foreground" />
            </span>
            <span className="text-lg font-semibold tracking-tight">
              LaunchFly<span className="text-gold">.io</span>
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}

function Hero() {
  return (
    <section className="relative -mt-20 px-6">
      <div className="mx-auto max-w-5xl text-center">

        <h1 className="mt-16 whitespace-nowrap text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl md:text-6xl">
          The first step from <span className="text-gradient-gold">idea to takeoff</span>.
        </h1>

        <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
          LaunchFly helps you go from “I want to start something” to knowing exactly what
          to build, how to start, and what to do next.
        </p>
        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <a
            href="#pricing"
            className="inline-flex items-center gap-2 rounded-full bg-gradient-gold px-6 py-3 text-base font-medium text-gold-foreground shadow-gold transition hover:opacity-90"
          >
            Start Your Launch — $19/month
            <ArrowRight className="h-4 w-4" />
          </a>
          <a
            href="#how"
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card/40 px-6 py-3 text-base font-medium text-foreground backdrop-blur transition hover:bg-card"
          >
            <PlayCircle className="h-4 w-4 text-gold" />
            See How It Works
          </a>
        </div>
      </div>
    </section>
  );
}

function ProblemCard({ icon: Icon, title, body }: { icon: any; title: string; body: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6 shadow-card-soft transition hover:border-gold/40">
      <div className="mb-4 grid h-10 w-10 place-items-center rounded-lg bg-secondary">
        <Icon className="h-5 w-5 text-gold" />
      </div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{body}</p>
    </div>
  );
}

function Problem() {
  return (
    <section className="px-6 py-28">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-semibold tracking-tight sm:text-4xl">
            You know you want to start.{" "}
            <span className="text-gradient-gold">LaunchFly tells you what to do next.</span>
          </h2>
        </div>
        <div className="mt-14 grid gap-5 md:grid-cols-3">
          <ProblemCard
            icon={Lightbulb}
            title="Too many ideas"
            body="You do not know which one to choose."
          />
          <ProblemCard
            icon={Compass}
            title="No clear first step"
            body="You know you want to build, but not where to begin."
          />
          <ProblemCard
            icon={MapIcon}
            title="No launch path"
            body="You need simple daily steps, not another vague business plan."
          />
        </div>
      </div>
    </section>
  );
}

function Step({ n, title, body }: { n: string; title: string; body: string }) {
  return (
    <div className="relative rounded-2xl border border-border bg-card p-6 shadow-card-soft">
      <div className="mb-4 inline-flex h-9 items-center justify-center rounded-md bg-gradient-gold px-3 text-sm font-semibold text-gold-foreground">
        Step {n}
      </div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{body}</p>
    </div>
  );
}

function HowItWorks() {
  return (
    <section id="how" className="border-y border-border bg-secondary/30 px-6 py-28">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-xs uppercase tracking-[0.25em] text-gold">How it works</p>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
            Four steps. One real launch.
          </h2>
        </div>
        <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          <Step n="1" title="Commit" body="Start your membership and enter your launch phase." />
          <Step n="2" title="Answer the survey" body="Share your skills, interests, time, budget, and goals." />
          <Step n="3" title="Choose your idea" body="Get personalized online business ideas matched to you." />
          <Step n="4" title="Follow your launch path" body="Get a simple plan, checklist, and daily next steps." />
        </div>
      </div>
    </section>
  );
}

function Feature({ icon: Icon, title, body }: { icon: any; title: string; body: string }) {
  return (
    <div className="group rounded-2xl border border-border bg-card p-6 shadow-card-soft transition hover:border-gold/50 hover:shadow-gold">
      <div className="mb-4 grid h-11 w-11 place-items-center rounded-lg bg-gradient-gold shadow-gold">
        <Icon className="h-5 w-5 text-gold-foreground" />
      </div>
      <h3 className="text-lg font-semibold">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{body}</p>
    </div>
  );
}

function Features() {
  const items = [
    { icon: Brain, title: "Founder DNA", body: "A short survey reveals your strengths, style, and ideal path." },
    { icon: Sparkles, title: "Personalized Ideas", body: "Online business ideas matched to your skills, time, and goals." },
    { icon: MapIcon, title: "Launch Blueprint", body: "A clear, structured plan from idea to first paying customer." },
    { icon: Target, title: "Today’s Launch Step", body: "One concrete action, every day. No more guessing what to do." },
    { icon: Zap, title: "MVP Prompt", body: "Ready-to-use prompts to build a real product fast." },
    { icon: Users, title: "First Customer Plan", body: "Outreach scripts and a simple plan to land your first user." },
  ];
  return (
    <section id="features" className="px-6 py-28">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-xs uppercase tracking-[0.25em] text-gold">Features</p>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
            Everything you need to actually take off.
          </h2>
        </div>
        <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {items.map((it) => (
            <Feature key={it.title} {...it} />
          ))}
        </div>
      </div>
    </section>
  );
}

function DashboardPreview() {
  return (
    <section className="px-6 py-24">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-2xl text-center">
          <p className="text-xs uppercase tracking-[0.25em] text-gold">Your dashboard</p>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
            A focused cockpit for your launch.
          </h2>
        </div>

        <div className="relative mt-14 overflow-hidden rounded-3xl border border-border bg-card p-6 shadow-card-soft sm:p-8">
          <div className="pointer-events-none absolute inset-0 bg-warm-glow" />
          <div className="relative grid gap-5 md:grid-cols-3">
            {/* Today's step */}
            <div className="md:col-span-2 rounded-2xl border border-border bg-background/60 p-6">
              <div className="flex items-center justify-between">
                <p className="text-xs uppercase tracking-widest text-gold">Today’s Launch Step</p>
                <span className="text-xs text-muted-foreground">Day 3 of 30</span>
              </div>
              <h3 className="mt-3 text-2xl font-semibold">Write your one-line value proposition</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Define who it’s for, what it does, and why it’s different — in a single sentence.
              </p>

              <div className="mt-5 h-2 w-full overflow-hidden rounded-full bg-secondary">
                <div className="h-full w-[10%] rounded-full bg-gradient-gold" />
              </div>

              <ul className="mt-6 space-y-3 text-sm">
                {[
                  "Pick your target customer",
                  "Draft 3 versions of your one-liner",
                  "Get feedback inside the dashboard",
                ].map((t, i) => (
                  <li key={t} className="flex items-center gap-3">
                    <CheckCircle2
                      className={`h-4 w-4 ${i === 0 ? "text-gold" : "text-muted-foreground"}`}
                    />
                    <span className={i === 0 ? "line-through text-muted-foreground" : ""}>{t}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Side cards */}
            <div className="space-y-5">
              <div className="rounded-2xl border border-border bg-background/60 p-5">
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4 text-gold" />
                  <p className="text-sm font-medium">MVP Prompt</p>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                  “Build a landing page that captures emails for [idea] with a hero, 3 benefits, and a waitlist form…”
                </p>
              </div>
              <div className="rounded-2xl border border-border bg-background/60 p-5">
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-gold" />
                  <p className="text-sm font-medium">Outreach Scripts</p>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                  3 personalized DM templates ready to send to your first 10 ideal users.
                </p>
              </div>
              <div className="rounded-2xl border border-border bg-background/60 p-5">
                <div className="flex items-center gap-2">
                  <Brain className="h-4 w-4 text-gold" />
                  <p className="text-sm font-medium">AI Founder Coach</p>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                  Ask anything. Get unstuck in seconds with context from your launch plan.
                </p>
              </div>
            </div>

            {/* Blueprint strip */}
            <div className="md:col-span-3 rounded-2xl border border-border bg-background/60 p-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MapIcon className="h-4 w-4 text-gold" />
                  <p className="text-sm font-medium">Launch Blueprint</p>
                </div>
                <span className="text-xs text-muted-foreground">30-day path</span>
              </div>
              <div className="mt-4 grid grid-cols-5 gap-2 sm:grid-cols-10">
                {Array.from({ length: 10 }).map((_, i) => (
                  <div
                    key={i}
                    className={`h-10 rounded-md border ${
                      i < 3
                        ? "border-gold/60 bg-gradient-gold/20"
                        : "border-border bg-secondary"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  const features = [
    "Founder DNA survey",
    "Personalized business ideas",
    "Launch Blueprint",
    "30-day launch path",
    "MVP prompts",
    "Outreach scripts",
    "AI founder coach",
    "Progress dashboard",
    "Cancel anytime",
  ];
  return (
    <section id="pricing" className="px-6 py-28">
      <div className="mx-auto max-w-3xl">
        <div className="text-center">
          <p className="text-xs uppercase tracking-[0.25em] text-gold">Pricing</p>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
            One simple plan. Built for momentum.
          </h2>
        </div>
        <div className="relative mt-12 overflow-hidden rounded-3xl border border-gold/40 bg-card p-8 shadow-gold sm:p-10">
          <div className="pointer-events-none absolute inset-0 bg-warm-glow" />
          <div className="relative">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-2xl font-semibold">LaunchFly Membership</h3>
                <p className="mt-1 text-sm text-muted-foreground">Everything you need to launch.</p>
              </div>
              <div className="text-right">
                <div className="text-4xl font-semibold">
                  <span className="text-gradient-gold">$19</span>
                  <span className="text-base text-muted-foreground">/month</span>
                </div>
              </div>
            </div>

            <ul className="mt-8 grid gap-3 sm:grid-cols-2">
              {features.map((f) => (
                <li key={f} className="flex items-center gap-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-gold" />
                  {f}
                </li>
              ))}
            </ul>

            <a
              href="#"
              className="mt-10 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gradient-gold px-6 py-3 text-base font-medium text-gold-foreground shadow-gold transition hover:opacity-90"
            >
              Start Your Launch
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

function FAQItem({ q, a }: { q: string; a: string }) {
  return (
    <details className="group rounded-2xl border border-border bg-card p-5 transition open:border-gold/40">
      <summary className="flex cursor-pointer items-center justify-between text-base font-medium">
        {q}
        <span className="ml-4 text-gold transition group-open:rotate-45">+</span>
      </summary>
      <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{a}</p>
    </details>
  );
}

function FAQ() {
  return (
    <section id="faq" className="border-t border-border bg-secondary/20 px-6 py-28">
      <div className="mx-auto max-w-3xl">
        <div className="text-center">
          <p className="text-xs uppercase tracking-[0.25em] text-gold">FAQ</p>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
            Questions before you take off.
          </h2>
        </div>
        <div className="mt-10 space-y-3">
          <FAQItem
            q="Do I need a business idea already?"
            a="No. LaunchFly will match you with personalized ideas based on your skills, interests, time, and goals."
          />
          <FAQItem
            q="How much time per day do I need?"
            a="Most members spend 30–60 minutes a day. Each step is small, focused, and designed to move you forward."
          />
          <FAQItem
            q="Can I cancel anytime?"
            a="Yes. It’s month-to-month. Cancel inside the dashboard whenever you’re done."
          />
          <FAQItem
            q="Is this just another course?"
            a="No. It’s a working dashboard, a personalized plan, and daily steps — not hours of videos."
          />
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section className="relative overflow-hidden px-6 py-32">
      <div className="pointer-events-none absolute inset-0 bg-warm-glow" />
      <div className="relative mx-auto max-w-3xl text-center">
        <h2 className="text-4xl font-semibold tracking-tight sm:text-5xl">
          Stop circling the idea.{" "}
          <span className="text-gradient-gold">Start flying.</span>
        </h2>
        <p className="mx-auto mt-5 max-w-xl text-lg text-muted-foreground">
          Get the first step, the next step, and a path you can actually follow.
        </p>
        <a
          href="#pricing"
          className="mt-10 inline-flex items-center gap-2 rounded-full bg-gradient-gold px-7 py-3.5 text-base font-medium text-gold-foreground shadow-gold transition hover:opacity-90"
        >
          Start Your Launch
          <ArrowRight className="h-4 w-4" />
        </a>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border px-6 py-10">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 sm:flex-row">
        <div className="flex items-center gap-2">
          <span className="grid h-7 w-7 place-items-center rounded-md bg-gradient-gold">
            <Rocket className="h-3.5 w-3.5 -rotate-45 text-gold-foreground" />
          </span>
          <span className="text-sm font-semibold">
            LaunchFly<span className="text-gold">.io</span>
          </span>
        </div>
        <p className="text-xs text-muted-foreground">
          © {new Date().getFullYear()} LaunchFly.io — The first step from idea to takeoff.
        </p>
      </div>
    </footer>
  );
}

function LandingPage() {
  return (
    <main className="min-h-screen bg-background text-foreground">
      <Nav />
      <Banner />
      <Hero />
      <Problem />
      <HowItWorks />
      <Features />
      <DashboardPreview />
      <Pricing />
      <FAQ />
      <FinalCTA />
      <Footer />
    </main>
  );
}

// Suppress unused import warning
void ListChecks;
